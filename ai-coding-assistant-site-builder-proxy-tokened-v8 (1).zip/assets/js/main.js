document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const explain = document.getElementById('btnExplain');
  const refactor = document.getElementById('btnRefactor');
  const suggestion = document.getElementById('suggestion');
  const code = document.getElementById('code');

  if (explain && suggestion && code) {
    explain.addEventListener('click', () => {
      suggestion.textContent = 'This function returns the sum of two numbers. Consider adding type checks.';
    });
  }
  if (refactor && suggestion) {
    refactor.addEventListener('click', () => {
      suggestion.textContent = 'function sum(...nums){\n  return nums.reduce((a, b) => a + b, 0)\n}';
    });
  }
});

// Ghost typewriter (constant slow speed)
(function(){
  const box = document.getElementById('ideaBox');
  const ghost = document.getElementById('ideaGhost');
  const launch = document.getElementById('launchBtn');
  if (!box || !ghost) return;

  const prompts = [
    "Build a responsive Next.js landing page with pricing & FAQ…",
    "Create a Flask REST API with JWT auth and /todos endpoints…",
    "Make a React dashboard with charts and dark mode…",
    "Generate a Node + Prisma blog with PostgreSQL…",
    "Create a weather app with OpenWeather API + favorites…",
    "Design a social feed with posts, comments & infinite scroll…"
  ];

  const SPEED_TYPE = 120;   // ms per character (typing)
  const SPEED_DELETE = 80;  // ms per character (deleting)
  const PAUSE_FULL = 2000;  // hold when full text shown
  const PAUSE_SWITCH = 500; // pause before next prompt

  let pi = 0, ci = 0, typing = true, stopped = false;
  let timer = null;

  function clearTimer(){ if (timer) { clearTimeout(timer); timer = null; } }

  function tick(){
    if (stopped) return;
    const current = prompts[pi];
    if (typing) {
      ghost.textContent = current.slice(0, ci + 1);
      ci++;
      if (ci >= current.length) {
        typing = false;
        timer = setTimeout(tick, PAUSE_FULL);
      } else {
        timer = setTimeout(tick, SPEED_TYPE);
      }
    } else {
      ghost.textContent = current.slice(0, ci - 1);
      ci--;
      if (ci <= 0) {
        typing = true;
        pi = (pi + 1) % prompts.length;
        timer = setTimeout(tick, PAUSE_SWITCH);
      } else {
        timer = setTimeout(tick, SPEED_DELETE);
      }
    }
  }

  function startCycle(){
    clearTimer();
    stopped = false;
    typing = true;
    ci = 0;
    ghost.textContent = "";
    timer = setTimeout(tick, SPEED_TYPE);
  }

  function stopCycle(){
    stopped = true;
    clearTimer();
    ghost.textContent = "";
  }

  // Halt while user interacts; resume on blur if empty
  ['focus','click','keydown','input','touchstart'].forEach(evt => {
    box.addEventListener(evt, stopCycle);
  });
  box.addEventListener('blur', ()=>{
    if (box.value.trim() === "") startCycle();
  });

  // Start after short delay
  setTimeout(startCycle, 800);

  // Chip/submit behavior left as-is in previous script
  function submitIdea(){
    const v = box.value.trim();
    if(!v) return;
    const url = "/builder.html?q=" + encodeURIComponent(v);
    window.location.href = url;
  }
  if (launch) launch.addEventListener('click', submitIdea);
  box.addEventListener('keydown', (e)=>{
    if ((e.key === 'Enter' && (e.metaKey || e.ctrlKey)) || (e.key === 'Enter' && !e.shiftKey)) {
      e.preventDefault();
      submitIdea();
    }
  });
})();

// Chip prompts start
(function(){
  const box = document.getElementById('ideaBox');
  if (!box) return;
  const proPrompts = {
    dashboard:
`You are an expert full‑stack engineer. Generate a production‑ready **React + Tailwind** admin dashboard with:
- Pages: Overview, Users, Revenue, Settings
- Widgets: KPI cards (users, MRR, churn), line/area charts, bar chart, recent activity
- Theme: light/dark toggle, responsive layout (mobile-first)
- Data: mock JSON services with async fetch and loading states
- Accessibility: landmarks, keyboard nav, ARIA labels
- Code quality: componentized, reusable hooks, utility classnames
Output clean HTML/CSS/JS (no build step).`,
    ecommerce:
`Generate a **Next.js** e‑commerce starter with product listing, detail, cart, and checkout:
- Filters: category, price, rating; server actions/API routes for cart ops
- Components: product card (image, price, color dots), sticky cart drawer
- SEO: JSON‑LD, meta; image optimization & lazy loading
- Payment stub with clear TODOs and types.`,
    social:
`Create a **Social Feed** app shell with posts, comments, likes, infinite scroll:
- Post card: avatar, username, timeago, text, optional gallery
- Composer: emoji picker, upload stub; optimistic UI for likes
- Pagination: cursor-based; modal accessibility and focus trapping
- Mobile-first responsive.`,
    portfolio:
`Produce a **minimal Portfolio** site:
- Sections: Hero, Projects grid, About, Contact form
- Project card: cover image/video, tags, CTA
- Theme switcher, prefers-color-scheme
- SEO: OpenGraph, canonical, sitemap template
- Pure Tailwind utilities.`,
    blog:
`Build a **Blog** scaffold:
- Index: search + tag filters
- Post: TOC, code highlight, copy-to-clipboard
- MDX-ready structure, next/prev nav
- RSS + sitemap, SEO meta, accessible headings.`,
    weather:
`Create a **Weather** app:
- City search (debounced), favorites list
- Current conditions + 7‑day forecast, unit toggle (°C/°F)
- Sunrise/sunset, wind, humidity
- Fetch wrapper with retry/backoff and clear API key notes
- Loading skeletons and error states.`
  };
  function insertPrompt(topic){
    const text = proPrompts[topic];
    if(!text) return;
    // Focus to stop any ghost animation and then insert text
    box.focus();
    box.value = text;
    // move cursor to end
    box.selectionStart = box.selectionEnd = box.value.length;
  }
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => insertPrompt(btn.getAttribute('data-topic')));
  });
})();
// Chip prompts end

// Set this to your backend origin if frontend is on a different host.
// Example: "https://your-project.vercel.app" or "https://your-worker.workers.dev"
// Leave empty ("") to use SAME-ORIGIN (/api/generate on current host).
window.BACKEND_URL = "";

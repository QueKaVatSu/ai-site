
// Simple end-to-end builder: chat on left, preview/code tabs on right.
// Default mode: TemplateSynth (no server). Optional: WebLLM (client-side) if enabled.
(function(){
  const $ = (sel, root=document)=>root.querySelector(sel);
  const chatEl = $("#chat");
  const input = $("#chat-input");
  const form = $("#chat-form");
  const sendBtn = $("#chat-send");
  const preview = $("#preview");
  const codeEl = $("#code");
  const tabPreview = $("#tab-preview");
  const tabCode = $("#tab-code");
  const copyBtn = $("#copy-code");
  const dlBtn = $("#download-zip");
  const statusEl = $("#gen-status");
  const llmToggle = null; const llmStatus = { textContent: "Hugging Face API" };
  

  // Inject year
  const yearEl = $("#year"); if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Tab switching
  function showPreview(){ preview.classList.remove("hidden"); codeEl.classList.add("hidden"); tabPreview.classList.add("bg-white"); tabCode.classList.remove("bg-white"); }
  function showCode(){ codeEl.classList.remove("hidden"); preview.classList.add("hidden"); tabCode.classList.add("bg-white"); tabPreview.classList.remove("bg-white"); }
  if (tabPreview) tabPreview.addEventListener("click", showPreview);
  if (tabCode) tabCode.addEventListener("click", showCode);

  // If query param q exists, seed the chat and trigger generation
  const params = new URLSearchParams(location.search);
  const seed = params.get("q");
  if (seed) {
    input.value = decodeURIComponent(seed);
    setTimeout(()=>form.dispatchEvent(new Event("submit",{cancelable:true})), 300);
  }

  // Message helpers
  function msg(role, text){
    const wrap = document.createElement("div");
    wrap.className = `flex ${role==="user"?"justify-end":""}`;
    const bubble = document.createElement("div");
    bubble.className = `max-w-[85%] rounded-2xl px-3 py-2 text-sm border ${role==="user"?"bg-slate-900 text-white border-slate-900":"bg-white border-slate-200"}`;
    bubble.innerText = text;
    wrap.appendChild(bubble);
    chatEl.appendChild(wrap);
    chatEl.scrollTop = chatEl.scrollHeight;
  }

  // Template-based synthesizer (free, deterministic)
  function synth(prompt){
    // Very naive classifier: pick layout and widgets based on keywords
    const p = prompt.toLowerCase();
    const wantsDark = /dark/.test(p);
    const title = (prompt.match(/(?:build|create|make|generate)\s+(.*?)(?:\sapp|\swebsite|$)/i)?.[1] || "App").replace(/[^a-z0-9\s\-]/ig,"");
    const themeBg = wantsDark ? "bg-slate-900 text-slate-100" : "bg-white text-slate-900";
    const card = wantsDark ? "bg-slate-800 border-slate-700" : "bg-white border-slate-200";
    const accent = wantsDark ? "#60a5fa" : "#4f46e5";

    let sections = [];
    if (/dashboard|admin|analytics|chart|kpi/.test(p)){
      sections.push(`<section class="grid md:grid-cols-3 gap-4">
        ${["Users","MRR","Churn"].map((k,i)=>`<div class="border ${card} rounded-xl p-4"><div class="text-xs text-slate-500">${k}</div><div class="text-2xl font-bold mt-1">${[1234,"$42k","2.1%"][i]}</div></div>`).join("")}
      </section>`);
    }
    if (/blog|post|article/.test(p)){
      sections.push(`<section class="grid md:grid-cols-2 gap-4">
        ${[1,2,3,4].map(i=>`<article class="border ${card} rounded-xl p-4"><h3 class="font-semibold">Post Title ${i}</h3><p class="text-sm mt-2 text-slate-600 ${wantsDark?"text-slate-300":""}">Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p></article>`).join("")}
      </section>`);
    }
    if (/e-?commerce|shop|product/.test(p)){
      sections.push(`<section class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        ${[1,2,3,4,5,6].map(i=>`<div class="border ${card} rounded-xl overflow-hidden"><div class="h-32 bg-slate-200 ${wantsDark?"bg-slate-700":""}"></div><div class="p-3"><div class="font-medium">Product ${i}</div><div class="text-sm text-slate-500 ${wantsDark?"text-slate-300":""}">$${(i*19).toFixed(2)}</div><button class="mt-2 px-3 py-1 rounded-lg border">${wantsDark?"Add":"Add to cart"}</button></div></div>`).join("")}
      </section>`);
    }
    if (sections.length===0){
      sections.push(`<section class="border ${card} rounded-xl p-6"><h3 class="font-semibold">Welcome</h3><p class="text-sm mt-2 ${wantsDark?"text-slate-300":"text-slate-600"}">This is a starter preview generated from your prompt.</p></section>`);
    }

    const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<title>${title || "App"}</title>
</head>
<body class="${themeBg}" style="font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;">
  <main class="max-w-5xl mx-auto p-6 space-y-6">
    <header class="flex items-center justify-between">
      <h1 class="text-2xl font-bold">${title || "App"}</h1>
      <a href="#" class="px-3 py-1 rounded-lg border" style="border-color:${accent}; color:${accent}">Action</a>
    </header>
    ${sections.join("\n")}
  </main>
</body>
</html>`;

    // Build "code" view by pretty concatenation
    const code = html;
    return { html, code };
  }

  // Optional WebLLM flow
  let engine = null;
  async function ensureEngine(){
    try{
      if (engine) return engine;
      if (!window.webllm) throw new Error("WebLLM not found");
      statusEl.textContent = "Loading model (no server)...";
      // pick a small model if available in this CDN release
      const model = "Llama-3.1-8B-Instruct-q4f32_1-MLC";
      engine = await webllm.CreateWebWorkerMLCEngine(
        new URL("https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm@0.2.69/dist/worker.js", window.location.href).href,
        { model }
      );
      llmStatus.textContent = "WebLLM ready";
      return engine;
    }catch(err){
      console.warn("WebLLM init failed:", err);
      llmToggle.checked = false;
      llmStatus.textContent = "Template Mode";
      engine = null;
      return null;
    } finally {
      statusEl.textContent = "Ready.";
    }
  }

  async function llmGenerate(prompt){
    const sys = "You are a senior full‑stack engineer. Generate a single self-contained HTML file that showcases the requested UI with Tailwind via CDN. If you include JS, put it in a single <script> tag. Keep it minimal but polished.";
    const eng = await ensureEngine();
    if (!eng) throw new Error("LLM not available");
    const out = await eng.chat.completions.create({
      messages: [
        { role: "system", content: sys },
        { role: "user", content: prompt }
      ],
      temperature: 0.4,
      max_tokens: 1024,
    });
    const text = out.choices?.[0]?.message?.content || "";
    return extractHtml(text);
  }

  function extractHtml(text){
    // Grab any ```html``` fenced block or fallback to raw
    const fence = text.match(/```(?:html)?\s*([\s\S]*?)```/i);
    const html = fence ? fence[1] : text;
    return { html, code: html };
  }

  // Render preview to iframe
  function render({html, code}){
    const doc = preview.contentDocument || preview.contentWindow.document;
    doc.open(); doc.write(html); doc.close();
    codeEl.textContent = code;
    showPreview();
  }

  // Download zip (single index.html inside)
  function downloadZip(code){
    const blob = new Blob([code], {type:"text/html"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "app.html"; a.click();
    URL.revokeObjectURL(url);
  }

  // Copy code
  if (copyBtn) copyBtn.addEventListener("click", ()=>{
    const code = codeEl.textContent || "";
    navigator.clipboard.writeText(code).then(()=>{
      statusEl.textContent = "Code copied."; setTimeout(()=>statusEl.textContent="Ready.", 1200);
    });
  });
  if (dlBtn) dlBtn.addEventListener("click", ()=>downloadZip(codeEl.textContent||""));

  // Toggle mode text
  if (llmToggle) llmToggle.addEventListener("change", async ()=>{
    if (llmToggle.checked){
      llmStatus.textContent = "Loading...";
      await ensureEngine();
    } else {
      llmStatus.textContent = "Template Mode";
    }
  });

  // Submit
  if (form) form.addEventListener("submit", async (e)=>{
    e.preventDefault();
    const prompt = input.value.trim();
    if (!prompt) return;
    msg("user", prompt);
    input.value = "";
    statusEl.textContent = "Generating (Hugging Face API)..." ;
    try{
      const res = await hfProxyGenerate(prompt);
      render(res);
      msg("assistant", "Generated preview and code on the right.");
      statusEl.textContent = "Done.";
    }catch(err){
      console.error(err);
      statusEl.textContent = "Generation failed; using template mode.";
      const res = synth(prompt);
      render(res);
      msg("assistant", "Backend unavailable; used Template generator as fallback.");
      statusEl.textContent = "Done.";
    }
  });

  // If arrived with seed query, ensure canvas is visible
  showPreview();
})();


  const API_BASE = (window.BACKEND_URL || '').replace(/\/$/, '');
  // Hugging Face via backend proxy (no token on client)
  async function hfProxyGenerate(prompt){
    const sys = "You are a senior full‑stack engineer. Return exactly ONE self‑contained HTML file using Tailwind via CDN. Include any JS in a single <script> tag. No explanations.";
    const res = await fetch(`${API_BASE}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, system: sys })
    });
    if (!res.ok) {
      throw new Error("Proxy error: " + res.status + " " + (await res.text()));
    }
    const data = await res.json();
    return { html: data.html, code: data.html };
  }

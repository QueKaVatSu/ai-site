// Cloudflare Worker - /api/generate
export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type"
        }
      });
    }
    if (request.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }
    try {
      const { prompt, system } = await request.json();
      if (!prompt) return new Response("Missing prompt", { status: 400 });

      const MODEL = "HuggingFaceH4/zephyr-7b-beta";
      const HF_TOKEN = "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";

      async function callOnce() {
        const r = await fetch(`https://api-inference.huggingface.co/models/${encodeURIComponent(MODEL)}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${HF_TOKEN}`
          },
          body: JSON.stringify({
            inputs: `${system || ""}\n\nUser: ${prompt}\n\nAssistant:`,
            parameters: { max_new_tokens: 1200, temperature: 0.25, return_full_text: false, do_sample: true }
          })
        });
        if (r.status === 503) return { loading: true };
        if (!r.ok) return { error: await r.text(), code: r.status };
        const data = await r.json();
        let text = "";
        if (Array.isArray(data) && data[0]?.generated_text) text = data[0].generated_text;
        else if (data.generated_text) text = data.generated_text;
        else if (data?.choices?.[0]?.message?.content) text = data.choices[0].message.content;
        else text = JSON.stringify(data);
        return { text };
      }

      let tries = 0, out = null;
      while (tries < 3 && !out) {
        const r = await callOnce();
        if (r?.error) return new Response(r.error, { status: r.code || 500 });
        if (!r.loading) out = r.text;
        else await new Promise(r => setTimeout(r, 4000));
        tries++;
      }
      if (!out) return new Response("Model still loading, try again.", { status: 503 });

      const m = out.match(/```(?:html)?\s*([\s\S]*?)```/i);
      const html = m ? m[1] : out;

      return new Response(JSON.stringify({ html }), {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    } catch (e) {
      return new Response(String(e), { status: 500 });
    }
  }
}

// /api/generate - Vercel Serverless Function
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method Not Allowed");
  try {
    const { prompt, system } = req.body || {};
    if (!prompt) return res.status(400).json({ error: "Missing prompt" });
    const HF_TOKEN = "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";
    const MODEL = process.env.HF_MODEL || "HuggingFaceH4/zephyr-7b-beta";

    async function callOnce() {
      const r = await fetch(`https://api-inference.huggingface.co/models/${encodeURIComponent(MODEL)}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${HF_TOKEN}`
        },
        body: JSON.stringify({
          inputs: `${system || ""}\n\nUser: ${prompt}\n\nAssistant:`,
          parameters: { max_new_tokens: 1200, temperature: 0.25, return_full_text: false, do_sample: true }
        })
      });
      if (r.status === 503) return { loading: true, text: null, eta: 5 };
      if (!r.ok) throw new Error(`HF error ${r.status}: ${await r.text()}`);
      const data = await r.json();
      let text = "";
      if (Array.isArray(data) && data[0]?.generated_text) text = data[0].generated_text;
      else if (data.generated_text) text = data.generated_text;
      else if (data?.choices?.[0]?.message?.content) text = data.choices[0].message.content;
      else text = JSON.stringify(data);
      return { loading: false, text };
    }

    let tries = 0, out = null;
    while (tries < 3) {
      const r = await callOnce();
      if (!r.loading) { out = r.text; break; }
      await new Promise(r => setTimeout(r, 4000));
      tries++;
    }

    if (!out) return res.status(503).send("Model still loading, try again.");

    const m = out.match(/```(?:html)?\s*([\s\S]*?)```/i);
    const html = m ? m[1] : out;

    // CORS for static hosting
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    return res.status(200).json({ html });
  } catch (e) {
    console.error(e);
    return res.status(500).send(String(e));
  }
}
